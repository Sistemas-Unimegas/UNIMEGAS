# -*- coding: utf-8 -*-
from . import ResCurrency
from . import ResPartnerGroup
from . import ResPartnerCredit
from . import ResPartner
from . import ResUsers
from . import ResCurrencyRate
