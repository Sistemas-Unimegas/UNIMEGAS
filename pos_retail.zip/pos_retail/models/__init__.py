# -*- coding: utf-8 -*-
from . import medical
from . import product
from . import pos
from . import account
from . import res
from . import sale
from . import stock
from . import purchase
from . import restaurant
from . import ir
from . import hr
