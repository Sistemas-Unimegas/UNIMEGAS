odoo.define('pos_retail.core_bus', function (require) {
    var bus = require('pos.bus');
    return bus
});
