odoo.define('pos_retail.base', function (require) {


});
