Fixing POS config could not save
------------------------------------------
- [x] client_header_buffer_size 64k;
- [x] large_client_header_buffers 4 64k;